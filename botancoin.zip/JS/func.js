function actnick(){
    if (document.getElementById('nick').value.length > 3){
        document.getElementById('nicksub').submit();
    }
}
setTimeout(() => {
    
}, timeout);