
var local, fd;
var active = document.getElementById('active');
local = localStorage.getItem('active');
function cli(obj){
    document.getElementById(obj).click();
}
function doc(obj){
    fd = document.getElementById(obj);
    return fd;
}
if (local == ''){
    cli('acc-click');
}
else{
    cli(local);
}