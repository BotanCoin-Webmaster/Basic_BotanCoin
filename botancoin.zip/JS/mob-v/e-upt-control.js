
function control(obj){
    if (obj.getAttribute('action') == 'no'){
        active.innerHTML = doc(obj.getAttribute('name')).innerHTML;
        localStorage.setItem('active', obj.getAttribute('id'));

        doc('acc-click').innerHTML = "<img class='bottom_img' src='IMG/BOTTOM/account_grey.png'><div class='mini_txt'>Профиль</div>";
        doc('search-click').innerHTML = "<img class='bottom_img' src='IMG/BOTTOM/search_grey.png'><div class='mini_txt'>Найти</div>";
        doc('stack-click').innerHTML = "<img width='35px' src='IMG/BOTTOM/stack_grey.png'>";
        doc('create-click').innerHTML = "<img class='bottom_img' src='IMG/BOTTOM/create_grey.png'><div class='mini_txt'>Создать</div>";
        doc('btn-click').innerHTML = "<img width='24px' src='IMG/BOTTOM/btn_grey.png'><div class='mini_txt'>Перевод</div>";

        doc('acc-click').setAttribute('action', 'no');
        doc('search-click').setAttribute('action', 'no');
        doc('stack-click').setAttribute('action', 'no');
        doc('create-click').setAttribute('action', 'no');
        doc('btn-click').setAttribute('action', 'no');

        if (obj.getAttribute('name') == 'account'){
            obj.innerHTML = "<img class='bottom_img' src='IMG/BOTTOM/"+ obj.getAttribute('name') +"_white.png'><div class='mini_txt'>Профиль</div>";
        }
        if (obj.getAttribute('name') == 'search'){
            obj.innerHTML = "<img class='bottom_img' src='IMG/BOTTOM/"+ obj.getAttribute('name') +"_white.png'><div class='mini_txt'>Найти</div>";
        }
        if (obj.getAttribute('name') == 'create'){
            obj.innerHTML = "<img class='bottom_img' src='IMG/BOTTOM/"+ obj.getAttribute('name') +"_white.png'><div class='mini_txt'>Создать</div>";
        }
        if (obj.getAttribute('name') == 'stack'){
            obj.innerHTML = "<img width='35px' src='IMG/BOTTOM/"+ obj.getAttribute('name') +"_white.png'>";
        }
        if (obj.getAttribute('name') == 'btn'){
            obj.innerHTML = "<img width='24px' src='IMG/BOTTOM/"+ obj.getAttribute('name') +"_white.png'><div class='mini_txt'>Перевод</div>";
        }
        
        obj.setAttribute('action', 'yes');
    }
}