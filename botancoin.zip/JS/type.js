$system_req = mysqli_query($link,"SELECT `id`, `text` FROM `system` ORDER BY `id` DESC LIMIT 5");
                    
                        while ($res_system = mysqli_fetch_array($system_req)) {
                            
                            echo "
                            
                            <div class='one_post newo'>
    <table class='post_table' style='text-align: left;'>
        <tr>
            <td class='post_txt' style='font-weight: 400; padding-bottom: 10px;'>
                <div style='word-break: break-word;  word-wrap: break-word;'>
                    {$res_system['text']}
                </div>
            </td>
        </tr>
        
        <tr>
            <td class='react_post' style='font-size: 16px; color: #3e3d45; word-break: break-word;  word-wrap: break-word;'>
                Системные уведомления
            </td>
        </tr>
        <tr>
            <td class='react_post'>
                <div class='like'>
                    <table class='up_like' name='uper'>
                        <tr>
                            <td><img src='IMG/INSTRUMENT/edit_blue.png' class='like_img'></td><td style='padding-left: 4px;'><div class='liky' style='display: inline-block;'></div> system\</td>
                        </tr>
                    </table>
                </div>
                <div class='views'>from school</div>
            </td>
        </tr>
    </table>
</div>
                                    </div>
                            
                            ";
                        }