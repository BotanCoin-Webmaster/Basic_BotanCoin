
var element2 = document.querySelector('#ident_2');
var Visible2 = function (target) {
  var targetPosition2 = {
      top: window.pageYOffset + target.getBoundingClientRect().top,
      left: window.pageXOffset + target.getBoundingClientRect().left,
      right: window.pageXOffset + target.getBoundingClientRect().right,
      bottom: window.pageYOffset + target.getBoundingClientRect().bottom
    },
    windowPosition2 = {
      top: window.pageYOffset,
      left: window.pageXOffset,
      right: window.pageXOffset + document.documentElement.clientWidth,
      bottom: window.pageYOffset + document.documentElement.clientHeight
    };

  if (targetPosition2.bottom > windowPosition2.top && 
    targetPosition2.top < windowPosition2.bottom &&
    targetPosition2.right > windowPosition2.left && 
    targetPosition2.left < windowPosition2.right) { 
    console.clear();
    
    
      $('.line_2').css('animation', 'right 2s forwards');

  } else {
      $('.line_2').css('animation', 'left 2s forwards');
  };
};

window.addEventListener('scroll', function() {
  Visible2 (element2);
});

Visible2 (element2);